﻿using ADODOTNETPROJ1.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADODOTNETPROJ1
{
    public partial class Deletedata : Form
    {
        StudentLogic ob = new StudentLogic();
        public Deletedata()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 ob1 = new Form1();
            ob1.Show();
            this.Hide();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtId.Value.ToString());
            DataSet res = ob.GetSearchData(id);
            if (Convert.ToInt32(res.Tables[0].Rows.Count.ToString()) > 0)
            {
                string msg = ob.DeleteData(id);
                MessageBox.Show(msg);
            }
            else
            {
                MessageBox.Show("Id does not exist");
            }
        }

        private void iNSERTToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
