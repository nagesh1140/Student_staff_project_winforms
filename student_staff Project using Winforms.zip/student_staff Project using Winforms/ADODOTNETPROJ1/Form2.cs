﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADODOTNETPROJ1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Sinsert ob = new Sinsert();
            ob.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Sdetails ob = new Sdetails();
            ob.Show();
            this.Hide();
        }

        private void iNSERTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sinsert ob = new Sinsert();
            ob.Show();
            this.Hide();
        }

        private void dETAILSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sdetails ob = new Sdetails();
            ob.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            StaffSearch ob = new StaffSearch();
            ob.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            StaffDelete ob = new StaffDelete();
            ob.Show();
            this.Hide();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            StaffUpdate ob = new StaffUpdate();
            ob.Show();
            this.Hide();
        }

        private void hOMEPAGEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            HomePage ob = new HomePage();
            ob.Show();
            this.Hide();
        }

        private void uPDATEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sinsert ob = new Sinsert();
            ob.Show();
            this.Hide();
        }

        private void dELETEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StaffDelete ob = new StaffDelete();
            ob.Show();
            this.Hide();
        }

        private void sEARCHToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StaffSearch ob = new StaffSearch();
            ob.Show();
            this.Hide();
        }
    }
}
