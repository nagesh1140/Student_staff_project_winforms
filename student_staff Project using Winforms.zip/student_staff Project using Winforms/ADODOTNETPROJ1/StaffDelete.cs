﻿using ADODOTNETPROJ1.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADODOTNETPROJ1
{
    public partial class StaffDelete : Form
    {
        StaffLogic ob = new StaffLogic();
        public StaffDelete()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtId.Value.ToString());
            DataSet res = ob.GetSearchData(id);
            if (Convert.ToInt32(res.Tables[0].Rows.Count.ToString()) > 0)
            {
                string msg = ob.DeleteData(id);
                MessageBox.Show(msg);
            }
            else
            {
                MessageBox.Show("Id does not exist");
            }
        }

        private void iNSERTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sinsert ob = new Sinsert();
            ob.Show();
            this.Hide();
        }

        private void uPDATEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StaffUpdate ob = new StaffUpdate();
            ob.Show();
            this.Hide();

        }

        private void dELETEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StaffDelete ob = new StaffDelete();
            ob.Show();
            this.Hide();
        }

        private void sEARCHToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StaffSearch ob = new StaffSearch();
            ob.Show();
            this.Hide();
        }

        private void dETAILSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sdetails ob = new Sdetails();
            ob.Show();
            this.Hide();
        }

        private void hOMEPAGEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            HomePage ob = new HomePage();
            ob.Show();
            this.Hide();
        }
    }
}
