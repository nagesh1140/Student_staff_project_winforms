﻿using ADODOTNETPROJ1.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADODOTNETPROJ1
{
    public partial class UpdateData : Form
    {
        StudentLogic ob = new StudentLogic();
        public UpdateData()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 ob1 = new Form1();
            ob1.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Student s = new Student();
            s.Id = Convert.ToInt32(txtId.Value);
            s.Name = textBox1.Text;
            s.Email = textBox3.Text;
            s.Phone = textBox2.Text;
            s.Fees = float.Parse(textBox4.Text.ToString());
            s.Percent = float.Parse(textBox5.Text.ToString());

            string msg = ob.Updatedata(s);
            MessageBox.Show(msg);
            dataGridView1.DataSource = ob.getStudentDetails();
            dataGridView1.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtId.Value.ToString());
            DataSet res = ob.GetSearchData(id);
            if (Convert.ToInt32(res.Tables[0].Rows.Count.ToString()) > 0)
            {
                panel1.Visible = true;
                textBox1.Text = res.Tables[0].Rows[0]["Name"].ToString();
                textBox3.Text = res.Tables[0].Rows[0]["Email"].ToString();
                textBox2.Text = res.Tables[0].Rows[0]["Phone"].ToString();
                textBox4.Text = res.Tables[0].Rows[0]["Fees"].ToString();
                textBox5.Text = res.Tables[0].Rows[0]["Percent"].ToString();
                btnUpdate.Visible = true;
                /*
                Student stu = new Student();
                stu.Id = id;
                stu.Name = res.Tables[0].Rows[0]["Name"].ToString();
                stu.Email = res.Tables[0].Rows[0]["Email"].ToString();
                stu.Phone = res.Tables[0].Rows[0]["Phone"].ToString();
                stu.Fees = float.Parse(res.Tables[0].Rows[0]["Fees"].ToString());
                stu.Percent = float.Parse(res.Tables[0].Rows[0]["Percent"].ToString());

                MessageBox.Show(stu.ToString());
                */
            }
            else
            {
                MessageBox.Show("Record wrt the id does not exist");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtId_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
