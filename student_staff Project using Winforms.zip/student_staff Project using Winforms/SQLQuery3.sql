﻿Insert into Staff values('nagesh',7,11)

select * from Staff