﻿create procedure sproc_deleteStaff
(
@id int
)
as
begin
delete from Staff
where Id=@id
end